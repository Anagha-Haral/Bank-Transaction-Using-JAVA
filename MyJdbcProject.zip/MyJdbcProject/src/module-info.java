/**
 * 
 */
/**
 * @author DELL
 *
 */
module MyJdbcProject {
	requires java.sql;
}