package com.amdocs.jdbcproject;

import java.sql.*;
public class BankTransCon
{
   public static void main(String args [])
   {
     try
     {
	// Loading the Database Driver
	Class.forName("oracle.jdbc.driver.OracleDriver");

	// Establish the Connection
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "root");

	// Create the Statement
	PreparedStatement selectStmtBankTrans = con.prepareStatement("SELECT TransID, AcctNo, OldBal, TransType, TransAmt, NewBal, TransStat FROM BankTrans");
	PreparedStatement selectStmtValidTrans = con.prepareStatement("SELECT TransID, TransType, TransAmt, Validity FROM ValidTrans");
	PreparedStatement selectStmtInvalidTrans = con.prepareStatement("SELECT TransID, TransType, TransAmt, Validity FROM InvalidTrans");


	// Execute the Statement and Returning ResultSet object
	ResultSet rs = selectStmtBankTrans.executeQuery();
	ResultSet rs1 = selectStmtValidTrans.executeQuery();
	ResultSet rs2 = selectStmtInvalidTrans.executeQuery();

	//Retrieving the data returned by the Statement
	System.out.println("\n Bank Transaction Table :");
   	while(rs.next())
   	{
   		int transId = rs.getInt("transId");
		String acctNo = rs.getString("acctno");
		double oldBal = rs.getDouble("oldBal");
		String transType = rs.getString("transType");
		double transAmt = rs.getDouble("transAmt");
		double newBal = rs.getDouble("newBal");
		String transStat = rs.getString("transStat");

		System.out.println(transId + " " + acctNo + " " + oldBal + " " + transType + " " + transAmt + " " + newBal + " " + transStat);
 
   	}	
	
   	System.out.println("\n Valid Transaction Table :");
   	while(rs1.next())
   	{
   		int transId = rs1.getInt("transId");
		String transType = rs1.getString("transType");
		double transAmt = rs1.getDouble("transAmt");
		String validity = rs1.getString("validity");
		
		System.out.println(transId + " " + transType + " " + transAmt + " " + validity);
 
   	}	
   	
   	System.out.println("\n Invalid Transaction Table :");
   	while(rs2.next())
   	{
   		int transId = rs2.getInt("transId");
		String transType = rs2.getString("transType");
		double transAmt = rs2.getDouble("transAmt");
		String validity = rs2.getString("validity");
		
		System.out.println(transId + " " + transType + " " + transAmt + " " + validity);
  
   	}	

   	
	con.close();
     }
     catch(Exception e)
     {
	e.printStackTrace();
     }


   }
}
