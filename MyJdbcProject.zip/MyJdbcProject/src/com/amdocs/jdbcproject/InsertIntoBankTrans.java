package com.amdocs.jdbcproject;

import java.sql.*;
public class InsertIntoBankTrans {
   public static void main(String args [])
   {
     try
     {
	// Loading the Database Driver
	Class.forName("oracle.jdbc.driver.OracleDriver");

	// Establish the Connection
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "root");

	
	//PreparedStatement selectStmt = con.prepareStatement("SELECT TransID, AcctNo, OldBal, TransType, TransAmt, NewBal, TransStat FROM BankTrans");
	PreparedStatement insertStmt = con.prepareStatement("INSERT INTO BankTrans(TransID, AcctNo, OldBal, TransType, TransAmt) VALUES(Trans_seq.nextval, ?, ?, ?, ?)");

	
	
		//Insert into banktrans table
		insertStmt.setLong(1, 1267964);
		insertStmt.setDouble(2, 40000 );
		insertStmt.setString(3, "W");
		insertStmt.setDouble(4, 41000);
		int rowInserted = insertStmt.executeUpdate();
		
		System.out.println(rowInserted + " Row(s) Inserted !!!"); 
	
	
	}
	catch(Exception E)
	{
		E.printStackTrace();
	}
    }
}
