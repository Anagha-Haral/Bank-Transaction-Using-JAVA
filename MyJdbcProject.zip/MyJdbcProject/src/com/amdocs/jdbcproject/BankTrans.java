package com.amdocs.jdbcproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BankTrans{
	// Method to calculate NewBal
	private static double calNewBal(double oldBal, double transAmt, String transType) {
		return transType.equals("D") ? oldBal + transAmt : oldBal - transAmt;
	}
	
	// Method to determine TransStat
	private static String detTransStat(double newBal) {
		return newBal >= 0 ? "Valid" : "Invalid";
	}
	
	public static void main(String args []){

		try{

		//Loading the Database Driver
		Class.forName("oracle.jdbc.driver.OracleDriver");

		//Establish the connection
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "root");

		//Create the Statement
		PreparedStatement selectStmt = con.prepareStatement("SELECT TransID, AcctNo, OldBal, TransType, TransAmt FROM BankTrans");
		PreparedStatement updateStmt = con.prepareStatement("UPDATE BankTrans SET NewBal=?, TransStat=? WHERE TransId=?");
		PreparedStatement insertValidStmt = con.prepareStatement("INSERT INTO ValidTrans VALUES (?, ?, ?, ?)");
		PreparedStatement insertInvalidStmt = con.prepareStatement("INSERT INTO InvalidTrans VALUES (?, ?, ?, ?)");

		//Execute the select Statement
		ResultSet rs = selectStmt.executeQuery();

		//Retrieving the data returned by the statement
		 while(rs.next()){
			int transId = rs.getInt("transId");
			String acctNo = rs.getString("acctno");
			double oldBal = rs.getDouble("oldBal");
			String transType = rs.getString("transType");
			double transAmt = rs.getDouble("transAmt");
			
			System.out.println(transId + " " + acctNo + " " + oldBal + " " + transType + " " + transAmt);

			// calling function calNewBal
			double newBal = calNewBal(oldBal, transAmt, transType);
			//double newBal = transType.equals("D") ? oldBal + transAmt : oldBal - transAmt;
			
			// calling function detTransStat
			String transStatus = detTransStat(newBal);
			//String transStatus = newBal >= 0 ? "Valid" : "Invalid";
			
			System.out.println(newBal + " " + transStatus);
			
		
			//Update NewBal and TransStat column in BankTrans table 
			updateStmt.setDouble(1, newBal);	
			updateStmt.setString(2, transStatus);
			updateStmt.setInt(3, transId);
			updateStmt.executeUpdate();
			
		
			// Insert into ValidTrans table
			if(transStatus.equals("Valid")){
				insertValidStmt.setInt(1, transId);
				insertValidStmt.setString(2, transType);
				insertValidStmt.setDouble(3, transAmt);
				insertValidStmt.setString(4, "Valid");
				insertValidStmt.executeUpdate();
				
			}
			
			
			// Insert into InvalidTrans table
			else {
				insertInvalidStmt.setInt(1, transId);
				insertInvalidStmt.setString(2, transType);
				insertInvalidStmt.setDouble(3, transAmt);
				insertInvalidStmt.setString(4, "Invalid");
				insertInvalidStmt.executeUpdate();
			}
			
			
		}
		 con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}